#ifndef ASSIMP_REVISION_H_INC
#define ASSIMP_REVISION_H_INC

#define GitVersion 0x80799bdbf
#define GitBranch "HEAD"

#endif // ASSIMP_REVISION_H_INC
